<?php //$title; ?>
<img class="post-thumb" src="<?php echo site_url(); ?>assets/img/banner.jpg">
<strong><h3>ciBlog Application</h3></strong>
<p>ciBlog Application is an hands-on simple blog application implemented using CodeIgniter PHP Framework.</p>
<h4>Features of ciBlog Application...</h4>
<ul class="list-group">
	<li class="list-group-item">
		Blog - shows the post contents...
	</li>
    <li class="list-group-item">
    	Categories - lists all categories of blog contents...
    </li>
    <li class="list-group-item">
    	View posts by categories..
    </li>
    <li class="list-group-item">
    	Create Post...
    </li>
    <li class="list-group-item">
    	Create Category...
    </li>
    <li class="list-group-item">
    	Edit Post...
    </li>
    <li class="list-group-item">
    	Delete Post...
    </li>
    <li class="list-group-item">
    	Post comment to a post content...
    </li>
    <li class="list-group-item">
    	View Comment posted to a post...
    </li>
    
</ul>
