<html>
	<head>
		<title>ciBlog</title>
		<link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" />
		<!-- BOOTSTRAP STYLES-->
		<link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
     <!-- FONTAWESOME STYLES-->
    <link href="<?php echo base_url();?>assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	</head>
	<body>
		<nav class="navbar navbar-inverse">
			<div class="container">
				<!-- <div class="navbar-header">
					<a class="navbar-brand" href=""<?php //echo base_url(); ?>">miBlog</a>
				</div> -->
				<div class="navbar-header">
					<a class="navbar-brand" href="<?php echo base_url(); ?>">Home</a>
				</div>
				<!-- <div class="navbar-header">
					<a class="navbar-brand" href="<?php //echo base_url(); ?>about">About</a>
				</div> -->
				<div class="navbar-header">
					<a class="navbar-brand" href="<?php echo base_url(); ?>posts">Blog</a>
				</div>
				<div class="navbar-header">
					<a class="navbar-brand" href="<?php echo base_url(); ?>categories">Categories</a>
				</div>
				<div class="navbar-header navbar-right">
					<a class="navbar-brand" href="<?php echo base_url(); ?>posts/create">Create Post</a>
					<a class="navbar-brand" href="<?php echo base_url(); ?>categories/create">Create Category</a>
				</div>

			</div>
		</nav>
		
		 <div class="container">  

                   
